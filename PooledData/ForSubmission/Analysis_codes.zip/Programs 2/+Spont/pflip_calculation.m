function[] = pflip_calculation(dXissbiais, pturn, wturn, wfor)



